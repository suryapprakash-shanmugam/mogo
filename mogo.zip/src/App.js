//import app css file
import './App.css';

//import Home page file
import Home from '../src/pages/Home/Home'
function App() {
  return (
    <div>
      <Home />
    </div>
  );
}

export default App;
