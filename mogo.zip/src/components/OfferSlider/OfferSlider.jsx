//import react packages
import React, { useRef, useState } from 'react'

//import mantine components
import { Container } from '@mantine/core'

//import OfferSlider css
import './OfferSlider.css'

//import swipper from swipper
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';


// import required modules
import { Autoplay, Navigation } from 'swiper/modules';

const OfferSlider = () => {

    //usestate for stop and play start the autoplay
    const [autoplayEnabled, setAutoplayEnabled] = useState(true);
    const swiperRef = useRef(null);

    const handleMouseEnter = () => {
        if (swiperRef.current && autoplayEnabled) {
            swiperRef.current.swiper.autoplay.stop();
            setAutoplayEnabled(false);
        }
    };

    const handleMouseLeave = () => {
        if (swiperRef.current && !autoplayEnabled) {
            swiperRef.current.swiper.autoplay.start();
            setAutoplayEnabled(true);
        }
    };

    return (
        <div>
            <div className='offerslider-div' onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
                <Container size={'82rem'} className='offerslider-div-container'>
                    <h2 className='offerslider-div-container-heading'>Special Offers</h2>
                    <Swiper
                        slidesPerView={1}
                        spaceBetween={10}
                        loop={true}
                        breakpoints={{
                            '@0.00': {
                                slidesPerView: 1,
                                spaceBetween: 10,
                            },
                            '@0.75': {
                                slidesPerView: 2,
                                spaceBetween: 20,
                            },
                            '@1.00': {
                                slidesPerView: 3,
                                spaceBetween: 40,
                            },
                            '@1.50': {
                                slidesPerView: 4,
                                spaceBetween: 50,
                            },
                        }}
                        navigation={true}
                        modules={[Autoplay, Navigation]}
                        autoplay={autoplayEnabled ? { delay: 2500 } : false}
                        noSwiping={!autoplayEnabled}
                        noSwipingClass="swiper-no-swiping"
                        ref={swiperRef}
                        className="mySwiper"
                    >
                        <SwiperSlide className='swiper-sliders'>Slide 1</SwiperSlide>
                        <SwiperSlide className='swiper-sliders'>Slide 1</SwiperSlide>
                        <SwiperSlide className='swiper-sliders'>Slide 1</SwiperSlide>
                        <SwiperSlide className='swiper-sliders'>Slide 1</SwiperSlide>
                        <SwiperSlide className='swiper-sliders'>Slide 1</SwiperSlide>
                    </Swiper>
                </Container>
            </div>
        </div>
    )
}

export default OfferSlider